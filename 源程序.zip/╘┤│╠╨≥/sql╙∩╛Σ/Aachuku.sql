/*
Navicat Oracle Data Transfer
Oracle Client Version : 10.2.0.5.0

Source Server         : oracle
Source Server Version : 110200
Source Host           : :1521
Source Schema         : SYSTEM

Target Server Type    : ORACLE
Target Server Version : 110200
File Encoding         : 65001

Date: 2018-09-14 16:00:49
*/


-- ----------------------------
-- Table structure for Aachuku
-- ----------------------------
DROP TABLE "SYSTEM"."Aachuku";
CREATE TABLE "SYSTEM"."Aachuku" (
"fenlei" VARCHAR2(255 BYTE) NOT NULL ,
"spname" VARCHAR2(255 BYTE) NOT NULL ,
"cknumber" NUMBER NOT NULL ,
"cktime" DATE NOT NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Checks structure for table Aachuku
-- ----------------------------
ALTER TABLE "SYSTEM"."Aachuku" ADD CHECK ("fenlei" IS NOT NULL);
ALTER TABLE "SYSTEM"."Aachuku" ADD CHECK ("spname" IS NOT NULL);
ALTER TABLE "SYSTEM"."Aachuku" ADD CHECK ("cknumber" IS NOT NULL);
ALTER TABLE "SYSTEM"."Aachuku" ADD CHECK ("cktime" IS NOT NULL);
