/*
Navicat Oracle Data Transfer
Oracle Client Version : 10.2.0.5.0

Source Server         : oracle
Source Server Version : 110200
Source Host           : :1521
Source Schema         : SYSTEM

Target Server Type    : ORACLE
Target Server Version : 110200
File Encoding         : 65001

Date: 2018-09-14 15:58:44
*/


-- ----------------------------
-- Table structure for Aauser
-- ----------------------------
DROP TABLE "SYSTEM"."Aauser";
CREATE TABLE "SYSTEM"."Aauser" (
"sno" NUMBER NOT NULL ,
"name" VARCHAR2(255 BYTE) NOT NULL ,
"sex" VARCHAR2(255 BYTE) NOT NULL ,
"mima" NUMBER NOT NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Indexes structure for table Aauser
-- ----------------------------

-- ----------------------------
-- Checks structure for table Aauser
-- ----------------------------
ALTER TABLE "SYSTEM"."Aauser" ADD CHECK ("mima" IS NOT NULL);
ALTER TABLE "SYSTEM"."Aauser" ADD CHECK ("sno" IS NOT NULL);
ALTER TABLE "SYSTEM"."Aauser" ADD CHECK ("name" IS NOT NULL);
ALTER TABLE "SYSTEM"."Aauser" ADD CHECK ("sex" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table Aauser
-- ----------------------------
ALTER TABLE "SYSTEM"."Aauser" ADD PRIMARY KEY ("sno");
