/*
Navicat Oracle Data Transfer
Oracle Client Version : 10.2.0.5.0

Source Server         : oracle
Source Server Version : 110200
Source Host           : :1521
Source Schema         : SYSTEM

Target Server Type    : ORACLE
Target Server Version : 110200
File Encoding         : 65001

Date: 2018-09-14 16:00:21
*/


-- ----------------------------
-- Table structure for Aaruku
-- ----------------------------
DROP TABLE "SYSTEM"."Aaruku";
CREATE TABLE "SYSTEM"."Aaruku" (
"fenlei" VARCHAR2(255 BYTE) NOT NULL ,
"spname" VARCHAR2(255 BYTE) NOT NULL ,
"rknumber" NUMBER NOT NULL ,
"rktime" DATE NOT NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Checks structure for table Aaruku
-- ----------------------------
ALTER TABLE "SYSTEM"."Aaruku" ADD CHECK ("fenlei" IS NOT NULL);
ALTER TABLE "SYSTEM"."Aaruku" ADD CHECK ("spname" IS NOT NULL);
ALTER TABLE "SYSTEM"."Aaruku" ADD CHECK ("rknumber" IS NOT NULL);
ALTER TABLE "SYSTEM"."Aaruku" ADD CHECK ("rktime" IS NOT NULL);
