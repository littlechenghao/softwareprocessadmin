/*
Navicat Oracle Data Transfer
Oracle Client Version : 10.2.0.5.0

Source Server         : oracle
Source Server Version : 110200
Source Host           : :1521
Source Schema         : SYSTEM

Target Server Type    : ORACLE
Target Server Version : 110200
File Encoding         : 65001

Date: 2018-09-14 16:00:40
*/


-- ----------------------------
-- Table structure for Aafenlei
-- ----------------------------
DROP TABLE "SYSTEM"."Aafenlei";
CREATE TABLE "SYSTEM"."Aafenlei" (
"fenlei" VARCHAR2(255 BYTE) NOT NULL ,
"beizhu" VARCHAR2(255 BYTE) NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Indexes structure for table Aafenlei
-- ----------------------------

-- ----------------------------
-- Checks structure for table Aafenlei
-- ----------------------------
ALTER TABLE "SYSTEM"."Aafenlei" ADD CHECK ("fenlei" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table Aafenlei
-- ----------------------------
ALTER TABLE "SYSTEM"."Aafenlei" ADD PRIMARY KEY ("fenlei");
