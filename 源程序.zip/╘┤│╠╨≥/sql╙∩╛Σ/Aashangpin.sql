/*
Navicat Oracle Data Transfer
Oracle Client Version : 10.2.0.5.0

Source Server         : oracle
Source Server Version : 110200
Source Host           : :1521
Source Schema         : SYSTEM

Target Server Type    : ORACLE
Target Server Version : 110200
File Encoding         : 65001

Date: 2018-09-14 16:00:04
*/


-- ----------------------------
-- Table structure for Aashangpin
-- ----------------------------
DROP TABLE "SYSTEM"."Aashangpin";
CREATE TABLE "SYSTEM"."Aashangpin" (
"fenlei" VARCHAR2(255 BYTE) NOT NULL ,
"spname" VARCHAR2(255 BYTE) NOT NULL ,
"beizhu" VARCHAR2(255 BYTE) NULL ,
"spnumber" NUMBER NULL 
)
LOGGING
NOCOMPRESS
NOCACHE

;

-- ----------------------------
-- Indexes structure for table Aashangpin
-- ----------------------------

-- ----------------------------
-- Checks structure for table Aashangpin
-- ----------------------------
ALTER TABLE "SYSTEM"."Aashangpin" ADD CHECK ("fenlei" IS NOT NULL);
ALTER TABLE "SYSTEM"."Aashangpin" ADD CHECK ("spname" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table Aashangpin
-- ----------------------------
ALTER TABLE "SYSTEM"."Aashangpin" ADD PRIMARY KEY ("spname");
