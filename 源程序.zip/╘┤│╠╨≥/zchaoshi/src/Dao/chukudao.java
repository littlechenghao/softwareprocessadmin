package Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Dbutil.dbutil;
import User.chuku;
import User.ruku;
import User.shangpin;

public class chukudao {
	public List<chuku> chaxunruku()
	{
		List<chuku> chuchu=new ArrayList<chuku>();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		chuku rara=null;
		String sql="select * from \"SYSTEM\".\"Aachuku\"";
		try {
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				rara=new chuku();
				rara.setFenlei(resultSet.getString("fenlei"));
				rara.setSpname(resultSet.getString("spname"));
				rara.setCknumber(resultSet.getInt("cknumber"));
				rara.setCktime(resultSet.getDate("cktime"));
				chuchu.add(rara);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return chuchu;
	}
	public List<chuku> chachuku(String xinxi,String xinxia)
	{
		List<chuku> ruru=new ArrayList<chuku>();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		chuku rara=null;
		Date axinxi=Date.valueOf(xinxi);
		Date axinxia=Date.valueOf(xinxia);
		String sql="select * from \"SYSTEM\".\"Aachuku\" where \"cktime\">=? and \"cktime\"<=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setDate(1, axinxi);
			preparedStatement.setDate(2, axinxia);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				rara=new chuku();
				rara.setFenlei(resultSet.getString("fenlei"));
				rara.setSpname(resultSet.getString("spname"));
				rara.setCknumber(resultSet.getInt("cknumber"));
				rara.setCktime(resultSet.getDate("cktime"));
				ruru.add(rara);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return ruru;
	}
	public int addchuku(chuku aa)
	{
		int r=0;
		PreparedStatement preparedStatement=null;
		Connection connection=Dbutil.dbutil.getconnection();//链接数据库
		String sql="select count(*) from \"SYSTEM\".\"Aashangpin\" where \"spname\"=? and \"fenlei\"=?";
		ResultSet resultSet=null;
		ResultSet rr=null;
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, aa.getSpname());
			preparedStatement.setString(2, aa.getFenlei());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				if(resultSet.getInt(1)==0)
				{
					r=-1;
				}
				else {
					sql="select \"spnumber\" from \"SYSTEM\".\"Aashangpin\" where \"spname\"=?";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setString(1, aa.getSpname());
					rr=preparedStatement.executeQuery();
					if(rr.next())
					{
						if(rr.getInt("spnumber")<aa.getCknumber())
						{
							r=-2;
						}
						else {
							sql="update \"SYSTEM\".\"Aashangpin\" set \"spnumber\"=\"spnumber\"-? where \"spname\"=?";
							preparedStatement=connection.prepareStatement(sql);
							preparedStatement.setInt(1, aa.getCknumber());
							preparedStatement.setString(2, aa.getSpname());
							preparedStatement.executeUpdate();
							sql="insert into \"SYSTEM\".\"Aachuku\"(\"fenlei\",\"spname\",\"cknumber\",\"cktime\")values(?,?,?,?)";
							preparedStatement=connection.prepareStatement(sql);
							preparedStatement.setString(1, aa.getFenlei());
							preparedStatement.setString(2, aa.getSpname());
							preparedStatement.setInt(3, aa.getCknumber());
							preparedStatement.setDate(4, aa.getCktime());
							r=preparedStatement.executeUpdate();
						}
					}
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(preparedStatement);
			dbutil.close(connection);
			dbutil.close(resultSet);
			dbutil.close(rr);
		}
		return r;
	}
	public int deletechuku(chuku aa)
	{
		int r=0;
		PreparedStatement preparedStatement=null;
		Connection connection=Dbutil.dbutil.getconnection();//链接数据库
		String sql="update \"SYSTEM\".\"Aashangpin\" set \"spnumber\"=\"spnumber\"+? where \"spname\"=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1, aa.getCknumber());
			preparedStatement.setString(2, aa.getSpname());
			preparedStatement.executeUpdate();
			sql="delete from \"SYSTEM\".\"Aachuku\" where \"fenlei\"=? and \"spname\"=? and \"cknumber\"=? and \"cktime\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, aa.getFenlei());
			preparedStatement.setString(2, aa.getSpname());
			preparedStatement.setInt(3, aa.getCknumber());
			preparedStatement.setDate(4, aa.getCktime());
			r=preparedStatement.executeUpdate();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(preparedStatement);
			dbutil.close(connection);
		}
		return r;
	}
}
