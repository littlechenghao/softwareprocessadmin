package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Dbutil.dbutil;
import User.shangpin;

public class shangpindao {
	public List<shangpin> chaxunsp()
	{
		List<shangpin> sss =new ArrayList<shangpin>();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		shangpin shangpin=null;
		String sql="select * from \"SYSTEM\".\"Aashangpin\"";
		try {
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				shangpin=new shangpin();
				shangpin.setFenlei(resultSet.getString("fenlei"));
				shangpin.setSpname(resultSet.getString("spname"));
				shangpin.setBeizhu(resultSet.getString("beizhu"));
				shangpin.setSpnumber(resultSet.getInt("spnumber"));
				sss.add(shangpin);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return sss;
	}
	public List<shangpin> chasp(String name)
	{
		List<shangpin> sss =new ArrayList<shangpin>();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		shangpin shangpin=null;
		String sql="select * from \"SYSTEM\".\"Aashangpin\" where \"spname\"=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, name);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				shangpin=new shangpin();
				shangpin.setFenlei(resultSet.getString("fenlei"));
				shangpin.setSpname(resultSet.getString("spname"));
				shangpin.setBeizhu(resultSet.getString("beizhu"));
				shangpin.setSpnumber(resultSet.getInt("spnumber"));
				sss.add(shangpin);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return sss;
	}
	public List<String> chaxunfl(){
		List<String> spfl=new ArrayList<String>();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String aString=null;
		String sql="select \"fenlei\" from \"SYSTEM\".\"Aafenlei\"";
		try {
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				aString=resultSet.getString("fenlei");
				spfl.add(aString);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return spfl;
	}
	public int addshangpin(shangpin haha)
	{
		int r=0;
		PreparedStatement preparedStatement=null;
		Connection connection=Dbutil.dbutil.getconnection();//链接数据库
		String sql="select count(*) from \"SYSTEM\".\"Aashangpin\" where \"spname\"=?";
		ResultSet resultSet=null;
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, haha.getSpname());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				if(resultSet.getInt(1)>0)
				{
					r=-1;
				}
				else {
					sql="insert into \"SYSTEM\".\"Aashangpin\"(\"fenlei\",\"spname\",\"beizhu\",\"spnumber\")values(?,?,?,?)";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setString(1, haha.getFenlei());
					preparedStatement.setString(2, haha.getSpname());
					preparedStatement.setString(3, haha.getBeizhu());
					preparedStatement.setInt(4, haha.getSpnumber());
					r=preparedStatement.executeUpdate();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(preparedStatement);
			dbutil.close(connection);
			dbutil.close(resultSet);
		}
		return r;
	}
	public int deleteshangpin(String spname)
	{
		int r=0;
		PreparedStatement preparedStatement=null;
		Connection connection=dbutil.getconnection();
		String sql="delete from \"SYSTEM\".\"Aaruku\" where \"spname\"=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, spname);
			preparedStatement.executeUpdate();
			sql="delete from \"SYSTEM\".\"Aachuku\" where \"spname\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, spname);
			preparedStatement.executeUpdate();
			sql="delete from \"SYSTEM\".\"Aashangpin\" where \"spname\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, spname);
			r=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return r;
	}
	public shangpin chaxunspa(String spname)
	{
		shangpin shangpin=new shangpin();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="select * from \"SYSTEM\".\"Aashangpin\" where \"spname\"=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, spname);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				shangpin.setSpname(resultSet.getString("spname"));
				shangpin.setFenlei(resultSet.getString("fenlei"));
				shangpin.setBeizhu(resultSet.getString("beizhu"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return shangpin;
	}
	public int updateshangpin(shangpin haha,String fenlei1,String spname1)
	{
		int r=0;
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="";
		try {
		if(haha.getSpname().equals(spname1))
		{
			sql="update \"SYSTEM\".\"Aaruku\" set \"fenlei\"=? where \"fenlei\"=? and \"spname\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, haha.getFenlei());
			preparedStatement.setString(2, fenlei1);
			preparedStatement.setString(3, spname1);
			r=preparedStatement.executeUpdate();
			sql="update \"SYSTEM\".\"Aachuku\" set \"fenlei\"=? where \"fenlei\"=? and \"spname\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, haha.getFenlei());
			preparedStatement.setString(2, fenlei1);
			preparedStatement.setString(3, spname1);
			r=preparedStatement.executeUpdate();
			sql="update \"SYSTEM\".\"Aashangpin\" set \"beizhu\"=?,\"fenlei\"=? where \"fenlei\"=? and\"spname\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, haha.getBeizhu());
			preparedStatement.setString(2, haha.getFenlei());
			preparedStatement.setString(3, fenlei1);
			preparedStatement.setString(4, spname1);
			r=preparedStatement.executeUpdate();
		}
		else 
		{
			sql="select count(*) from \"SYSTEM\".\"Aashangpin\" where \"spname\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, haha.getSpname());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				r=resultSet.getInt(1);
			}
			if(r==1)
			{
				return -1;
			}
			else {
				sql="update \"SYSTEM\".\"Aaruku\" set \"fenlei\"=?,\"spname\"=? where \"fenlei\"=? and \"spname\"=?";
				preparedStatement=connection.prepareStatement(sql);
				preparedStatement.setString(1, haha.getFenlei());
				preparedStatement.setString(2, haha.getSpname());
				preparedStatement.setString(3, fenlei1);
				preparedStatement.setString(4, spname1);
				r=preparedStatement.executeUpdate();
				sql="update \"SYSTEM\".\"Aachuku\" set \"fenlei\"=?,\"spname\"=? where \"fenlei\"=? and \"spname\"=?";
				preparedStatement=connection.prepareStatement(sql);
				preparedStatement.setString(1, haha.getFenlei());
				preparedStatement.setString(2, haha.getSpname());
				preparedStatement.setString(3, fenlei1);
				preparedStatement.setString(4, spname1);
				r=preparedStatement.executeUpdate();
				sql="update \"SYSTEM\".\"Aashangpin\" set \"beizhu\"=?,\"fenlei\"=?,\"spname\"=? where \"fenlei\"=? and\"spname\"=?";
				preparedStatement=connection.prepareStatement(sql);
				preparedStatement.setString(1, haha.getBeizhu());
				preparedStatement.setString(2, haha.getFenlei());
				preparedStatement.setString(3, haha.getSpname());
				preparedStatement.setString(4, fenlei1);
				preparedStatement.setString(5, spname1);
				r=preparedStatement.executeUpdate();
			}
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return r;
	}
	public List<String> chaxunspm()
	{
		List<String> spfl=new ArrayList<String>();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String aString=null;
		String sql="select \"spname\" from \"SYSTEM\".\"Aashangpin\"";
		try {
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				aString=resultSet.getString("spname");
				//System.out.println(aString);
				spfl.add(aString);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return spfl;
	}
}
