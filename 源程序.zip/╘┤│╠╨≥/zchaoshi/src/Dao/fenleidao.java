package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Dbutil.dbutil;
import User.fenlei;

public class fenleidao {
	public List<fenlei> chaxunfenlei()
	{
		List<fenlei> fenleis=new ArrayList<fenlei>();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="select * from \"SYSTEM\".\"Aafenlei\"";
		try {
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			fenlei ff=null;
			while(resultSet.next())
			{
				ff=new fenlei();
				ff.setFenlei(resultSet.getString("fenlei"));
				ff.setBeizhu(resultSet.getString("beizhu"));
				fenleis.add(ff);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return fenleis;
	}
	public List<fenlei> chafenlei(String name)
	{
		List<fenlei> fenleis=new ArrayList<fenlei>();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="select * from \"SYSTEM\".\"Aafenlei\" where \"fenlei\"=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, name);
			resultSet=preparedStatement.executeQuery();
			fenlei ff=null;
			while(resultSet.next())
			{
				ff=new fenlei();
				ff.setFenlei(resultSet.getString("fenlei"));
				ff.setBeizhu(resultSet.getString("beizhu"));
				fenleis.add(ff);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return fenleis;
	}
	public int deletefenlei(String fenlei)
	{
		int r=0;
		PreparedStatement preparedStatement=null;
		Connection connection=dbutil.getconnection();
		String sql="delete from \"SYSTEM\".\"Aaruku\" where \"fenlei\"=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, fenlei);
			preparedStatement.executeUpdate();
			sql="delete from \"SYSTEM\".\"Aachuku\" where \"fenlei\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, fenlei);
			preparedStatement.executeUpdate();
			sql="delete from \"SYSTEM\".\"Aashangpin\" where \"fenlei\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, fenlei);
			preparedStatement.executeUpdate();
			sql="delete from \"SYSTEM\".\"Aafenlei\" where \"fenlei\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, fenlei);
			r=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
		}
		return r;
	}
	public int addfenlei(fenlei ff)
	{
		int r=0;
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="select count(*) from \"SYSTEM\".\"Aafenlei\" where \"fenlei\"=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, ff.getFenlei());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				r=resultSet.getInt(1);
			}
			if(r==1)
			{
				return -1;
			}
			else {
				sql="insert into \"SYSTEM\".\"Aafenlei\"(\"fenlei\",\"beizhu\") values(?,?)";
				preparedStatement=connection.prepareStatement(sql);
				preparedStatement.setString(1, ff.getFenlei());
				preparedStatement.setString(2, ff.getBeizhu());
				r=preparedStatement.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return r;
	}
	public fenlei chaxunff(String name)
	{
		fenlei ff=new fenlei();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="select * from \"SYSTEM\".\"Aafenlei\" where \"fenlei\"=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, name);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				ff.setFenlei(resultSet.getString("fenlei"));
				ff.setBeizhu(resultSet.getString("beizhu"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return ff;
	}
	public int updatefenlei(fenlei ff,String name)
	{
		int r=0;
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		String sql="select count(*) from \"SYSTEM\".\"Aafenlei\" where \"fenlei\"=?";
		try {
			if(ff.getFenlei().equals(name))
			{
				sql="update \"SYSTEM\".\"Aafenlei\" set \"fenlei\"=?,\"beizhu\"=? where \"fenlei\"=?";
				preparedStatement=connection.prepareStatement(sql);
				preparedStatement.setString(1, ff.getFenlei());
				preparedStatement.setString(2, ff.getBeizhu());
				preparedStatement.setString(3, name);
				r=preparedStatement.executeUpdate();
			}
			else {
				preparedStatement=connection.prepareStatement(sql);
				preparedStatement.setString(1, ff.getFenlei());
				resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					r=resultSet.getInt(1);
				}
				if(r==1)
				{
					return -1;
				}
				else {
					sql="update \"SYSTEM\".\"Aaruku\" set \"fenlei\"=? where \"fenlei\"=?";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setString(1, ff.getFenlei());
					preparedStatement.setString(2, name);
					r=preparedStatement.executeUpdate();
					sql="update \"SYSTEM\".\"Aachuku\" set \"fenlei\"=? where \"fenlei\"=?";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setString(1, ff.getFenlei());
					preparedStatement.setString(2, name);
					r=preparedStatement.executeUpdate();
					sql="update \"SYSTEM\".\"Aashangpin\" set \"fenlei\"=? where \"fenlei\"=?";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setString(1, ff.getFenlei());
					preparedStatement.setString(2, name);
					r=preparedStatement.executeUpdate();
					sql="update \"SYSTEM\".\"Aafenlei\" set \"fenlei\"=?,\"beizhu\"=? where \"fenlei\"=?";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setString(1, ff.getFenlei());
					preparedStatement.setString(2, ff.getBeizhu());
					preparedStatement.setString(3, name);
					r=preparedStatement.executeUpdate();
			}
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return r;
	}
}
