package Dao;
import Dbutil.UserException;
import Dbutil.dbutil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import User.user;

public class userdao {
	public int index(int sno,int pwd)
	{
		int r=0;
		PreparedStatement preparedStatement=null;
		Connection connection=dbutil.getconnection();
		String sql="select \"mima\" from \"SYSTEM\".\"Aauser\" where \"sno\"=?";
		ResultSet resultSet=null;
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1,sno);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				int pass=resultSet.getInt("mima");
				if(pass==pwd)
				{
					r=1;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(resultSet);
			dbutil.close(preparedStatement);
		}
		return r;
	}
	public int add(user uu)
	{
		int r=0;
		PreparedStatement preparedStatement=null;
		Connection connection=Dbutil.dbutil.getconnection();//链接数据库
		String sql="select count(*) from \"SYSTEM\".\"Aauser\" where \"sno\"=?";
		ResultSet resultSet=null;
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1, uu.getSno());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				if(resultSet.getInt(1)>0)
				{
					r=2;
				}
				else {
					sql="insert into \"SYSTEM\".\"Aauser\"(\"sno\",\"name\",\"sex\",\"mima\")values(?,?,?,?)";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setInt(1, uu.getSno());
					preparedStatement.setString(2, uu.getName());
					preparedStatement.setString(3, uu.getSex());
					preparedStatement.setInt(4, uu.getPassword());
					r=preparedStatement.executeUpdate();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(preparedStatement);
			dbutil.close(connection);
			dbutil.close(resultSet);
		}
		return r;
	}
	public List<user> chaxunuser()
	{
		Connection connection=dbutil.getconnection();
		String sql="select * from \"SYSTEM\".\"Aauser\"";
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		List<user> uaua=new ArrayList<user>();
		user uu=null;
		try {
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				if(resultSet.getInt("sno")!=123)
				{
					uu=new user();
					//System.out.println(resultSet.getInt("sno"));
					uu.setSno(resultSet.getInt("sno"));
					uu.setName(resultSet.getString("name"));
					uu.setSex(resultSet.getString("sex"));
					uaua.add(uu);
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(resultSet);
			dbutil.close(preparedStatement);
		}
		return uaua;
	}
	public int delete(int sno)
	{
		int r=0;
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		String sql="delete from \"SYSTEM\".\"Aauser\" where \"sno\" =?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1, sno);
			r=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return r;
	}
	public int updatemima(int sno,int mima1,int mima2)
	{
		int r=0;
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		int bijiao=0;
		String sql="select \"mima\" from \"SYSTEM\".\"Aauser\" where \"sno\"=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1, sno);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				bijiao=resultSet.getInt("mima");
			}
			if(bijiao!=mima1) {
				return -1;
			}
			else if(bijiao==mima1) {
				sql="update \"SYSTEM\".\"Aauser\" set \"mima\"=? where \"sno\"=?";
				preparedStatement=connection.prepareStatement(sql);
				preparedStatement.setInt(1, mima2);
				preparedStatement.setInt(2, sno);
				r=preparedStatement.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return r;
	}
	public List<user> chauser(String name)
	{
		Connection connection=dbutil.getconnection();
		String sql="select * from \"SYSTEM\".\"Aauser\" where \"sno\"=?";
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		int a=Integer.parseInt(name);
		List<user> uaua=new ArrayList<user>();
		user uu=null;
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1, a);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				if(resultSet.getInt("sno")!=123)
				{
					uu=new user();
					//System.out.println(resultSet.getInt("sno"));
					uu.setSno(resultSet.getInt("sno"));
					uu.setName(resultSet.getString("name"));
					uu.setSex(resultSet.getString("sex"));
					uaua.add(uu);
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(resultSet);
			dbutil.close(preparedStatement);
		}
		return uaua;
	}
}
