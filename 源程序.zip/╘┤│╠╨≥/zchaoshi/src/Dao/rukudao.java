package Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.fabric.xmlrpc.base.Data;

import Dbutil.dbutil;
import User.ruku;
import User.shangpin;

public class rukudao {
	public List<ruku> chaxunruku()
	{
		List<ruku> ruru=new ArrayList<ruku>();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		ruku rara=null;
		String sql="select * from \"SYSTEM\".\"Aaruku\"";
		try {
			preparedStatement=connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				rara=new ruku();
				rara.setFenlei(resultSet.getString("fenlei"));
				rara.setSpname(resultSet.getString("spname"));
				rara.setRknumber(resultSet.getInt("rknumber"));
				rara.setRktime(resultSet.getDate("rktime"));
				ruru.add(rara);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return ruru;
	}
	public List<ruku> charuku(String xinxi,String xinxia)
	{
		List<ruku> ruru=new ArrayList<ruku>();
		Connection connection=dbutil.getconnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		ruku rara=null;
		Date axinxi=Date.valueOf(xinxi);
		Date axinxia=Date.valueOf(xinxia);
		String sql="select * from \"SYSTEM\".\"Aaruku\" where \"rktime\">=? and \"rktime\"<=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setDate(1, axinxi);
			preparedStatement.setDate(2, axinxia);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				rara=new ruku();
				rara.setFenlei(resultSet.getString("fenlei"));
				rara.setSpname(resultSet.getString("spname"));
				rara.setRknumber(resultSet.getInt("rknumber"));
				rara.setRktime(resultSet.getDate("rktime"));
				ruru.add(rara);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(connection);
			dbutil.close(preparedStatement);
			dbutil.close(resultSet);
		}
		return ruru;
	}
	public int addruku(ruku aa)
	{
		int r=0;
		PreparedStatement preparedStatement=null;
		Connection connection=Dbutil.dbutil.getconnection();//链接数据库
		String sql="select count(*) from \"SYSTEM\".\"Aashangpin\" where \"spname\"=? and \"fenlei\"=?";
		ResultSet resultSet=null;
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, aa.getSpname());
			preparedStatement.setString(2, aa.getFenlei());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				if(resultSet.getInt(1)==0)
				{
					r=-1;
				}
				else {
					sql="update \"SYSTEM\".\"Aashangpin\" set \"spnumber\"=\"spnumber\"+? where \"spname\"=?";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setInt(1, aa.getRknumber());
					preparedStatement.setString(2, aa.getSpname());
					preparedStatement.executeUpdate();
					sql="insert into \"SYSTEM\".\"Aaruku\"(\"fenlei\",\"spname\",\"rknumber\",\"rktime\")values(?,?,?,?)";
					preparedStatement=connection.prepareStatement(sql);
					preparedStatement.setString(1, aa.getFenlei());
					preparedStatement.setString(2, aa.getSpname());
					preparedStatement.setInt(3, aa.getRknumber());
					preparedStatement.setDate(4, aa.getRktime());
					r=preparedStatement.executeUpdate();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(preparedStatement);
			dbutil.close(connection);
			dbutil.close(resultSet);
		}
		return r;
	}
	public int deleteruku(ruku aa)
	{
		int r=0;
		PreparedStatement preparedStatement=null;
		Connection connection=Dbutil.dbutil.getconnection();//链接数据库
		String sql="update \"SYSTEM\".\"Aashangpin\" set \"spnumber\"=\"spnumber\"-? where \"spname\"=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1, aa.getRknumber());
			preparedStatement.setString(2, aa.getSpname());
			preparedStatement.executeUpdate();
			sql="delete from \"SYSTEM\".\"Aaruku\" where \"fenlei\"=? and \"spname\"=? and \"rknumber\"=? and \"rktime\"=?";
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, aa.getFenlei());
			preparedStatement.setString(2, aa.getSpname());
			preparedStatement.setInt(3, aa.getRknumber());
			preparedStatement.setDate(4, aa.getRktime());
			r=preparedStatement.executeUpdate();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbutil.close(preparedStatement);
			dbutil.close(connection);
		}
		return r;
	}
}
