package Servlets;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.*;

import Dao.chukudao;
import Dao.fenleidao;
import Dao.rukudao;
import Dao.shangpindao;
import Dao.userdao;
import Dbutil.UserException;
import User.chuku;
import User.fenlei;
import User.ruku;
import User.shangpin;
import User.user;
@WebServlet("*.do")
public class servlets extends HttpServlet{
	private static final long serialVersionUID = 1L;
	/**
	 * 截获所有的后缀为.do请求，并转到相应的处理程序
	 */
	public servlets() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String actionUrl=request.getServletPath();//获取用户请求的路径
		if(actionUrl.equals("/jsp/index.do"))
		{
			//System.out.println("登录");
			int r=0;
			request.setCharacterEncoding("UTF-8");
			int sno=Integer.parseInt(request.getParameter("username"));
			int mima=Integer.parseInt(request.getParameter("password"));
			userdao userdao=new userdao();
			r=userdao.index(sno, mima);
			if(r==1)
			{
				if(sno!=123)
				{
					request.getRequestDispatcher("/jsp/main.jsp?username="+sno).forward(request, response);
				}
				else if(sno==123)
				{
					request.getRequestDispatcher("/jsp/supermain.jsp").forward(request, response);	
				}
			}
			else {
				request.getRequestDispatcher("/jsp/index.jsp?error=1").forward(request, response);
			}
		}
		else if(actionUrl.equals("/jsp/add.do"))
		{
			System.out.println("GG");
			int r=0;
			request.setCharacterEncoding("UTF-8");
			user user=new user();
			user.setSno(Integer.parseInt(request.getParameter("username")));
			user.setName(request.getParameter("zhenname"));
			user.setSex(request.getParameter("sex"));
			user.setPassword(Integer.parseInt(request.getParameter("password")));
			userdao userdao=new userdao();
			r=userdao.add(user);
			if(r==1)
			{
				request.getRequestDispatcher("/jsp/index.jsp?error=2").forward(request, response);
			}
			else if(r==2)
			{
				request.getRequestDispatcher("/jsp/register.jsp?error=1").forward(request, response);
			}
			else {
				request.getRequestDispatcher("/jsp/register.jsp?error=2").forward(request, response);
			}
		}
		else if(actionUrl.equals("/jsp/delete.do"))
		{
			int r=0;
			int id=Integer.parseInt(request.getParameter("id"));
			System.out.println(id);
			request.setCharacterEncoding("UTF-8");
			userdao userdao=new userdao();
			r=userdao.delete(id);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/updatemima.do"))
		{
			int r=0;
			int sno=Integer.parseInt(request.getParameter("sno"));
			int mima1=Integer.parseInt(request.getParameter("mima1"));
			int mima2=Integer.parseInt(request.getParameter("mima2"));
			request.setCharacterEncoding("UTF-8");
			userdao userdao=new userdao();
			r=userdao.updatemima(sno, mima1, mima2);
			System.out.println(r);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/deletefenlei.do"))
		{
			int r=0;
			String id=request.getParameter("id");
			System.out.println(id);
			request.setCharacterEncoding("UTF-8");
			fenleidao fenleidao=new fenleidao();
			r=fenleidao.deletefenlei(id);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/addfenlei.do"))
		{
			int r=0;
			String name=request.getParameter("name");
			String beizhu=request.getParameter("beizhu");
			fenlei fenlei=new fenlei();
			fenleidao fenleidao=new fenleidao();
			fenlei.setFenlei(name);
			fenlei.setBeizhu(beizhu);
			r=fenleidao.addfenlei(fenlei);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/editfenlei.do"))
		{
			System.out.println("GG");
			fenlei ff=new fenlei();
			String id=request.getParameter("id");
			fenleidao fenleidao=new fenleidao();
			ff=fenleidao.chaxunff(id);
			response.setContentType("text/html;charset=UTF-8");
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("fenlei", ff.getFenlei());
			map.put("beizhu", ff.getBeizhu());
			JSONObject BookObj = new JSONObject(map);
			response.getWriter().print(BookObj.toString());
		}
		else if(actionUrl.equals("/jsp/updatefenlei.do"))
		{
			int r=0;
			String name=request.getParameter("name");
			String beizhu=request.getParameter("beizhu");
			String fenl=request.getParameter("fenlei");
			fenlei fenlei=new fenlei();
			fenleidao fenleidao=new fenleidao();
			fenlei.setFenlei(name);
			fenlei.setBeizhu(beizhu);
			r=fenleidao.updatefenlei(fenlei, fenl);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/addshangpin.do"))
		{
			int r=0;
			String fenlei=request.getParameter("fenlei");
			String spname=request.getParameter("spname");		
			String beizhu=request.getParameter("beizhu");
			int spnumber=Integer.parseInt(request.getParameter("spnumber"));
			shangpin spa=new shangpin();
			spa.setFenlei(fenlei);
			spa.setSpname(spname);
			spa.setBeizhu(beizhu);
			spa.setSpnumber(spnumber);
			shangpindao shangpindao=new shangpindao();
			r=shangpindao.addshangpin(spa);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/deleteshangpin.do"))
		{
			int r=0;
			String id=request.getParameter("id");
			shangpindao shangpindao=new shangpindao();
			r=shangpindao.deleteshangpin(id);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/editshangpin.do"))
		{
			shangpin spp=new shangpin();
			String id=request.getParameter("id");
			shangpindao shangpindao=new shangpindao();
			spp=shangpindao.chaxunspa(id);
			response.setContentType("text/html;charset=UTF-8");
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("spname", spp.getSpname());
			map.put("fenlei", spp.getFenlei());
			map.put("beizhu", spp.getBeizhu());
			JSONObject BookObj = new JSONObject(map);
			response.getWriter().print(BookObj.toString());
		}
		else if(actionUrl.equals("/jsp/updateshangpin.do"))
		{
			int r=0;
			String spname=request.getParameter("spname");
			String spname1=request.getParameter("spname1");
			String beizhu=request.getParameter("beizhu");
			String fenlei=request.getParameter("fenlei");
			String fenlei1=request.getParameter("fenlei1");
			shangpin ssShangpin=new shangpin();
			ssShangpin.setSpname(spname);
			ssShangpin.setFenlei(fenlei);
			ssShangpin.setBeizhu(beizhu);
			shangpindao shangpindao=new shangpindao();
			r=shangpindao.updateshangpin(ssShangpin, fenlei1, spname1);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/addruku.do"))
		{
			int r=0;
			String fenlei=request.getParameter("fenlei");
			String spname=request.getParameter("spname");
			int rknumber=Integer.parseInt(request.getParameter("rknumber"));
			Date rktime=Date.valueOf(request.getParameter("rkdate"));
			ruku ra=new ruku();
			ra.setFenlei(fenlei);
			ra.setSpname(spname);
			ra.setRknumber(rknumber);
			ra.setRktime(rktime);
			rukudao rr=new rukudao();
			r=rr.addruku(ra);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/deleteruku.do"))
		{
			int r=0;
			String fenlei=request.getParameter("fenlei");
			String spname=request.getParameter("spname");
			int rknumber=Integer.parseInt(request.getParameter("rknumber"));
			Date rktime=Date.valueOf(request.getParameter("rktime"));
			ruku ra=new ruku();
			ra.setFenlei(fenlei);
			ra.setSpname(spname);
			ra.setRknumber(rknumber);
			ra.setRktime(rktime);
			rukudao rr=new rukudao();
			r=rr.deleteruku(ra);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/addchuku.do"))
		{
			int r=0;
			String fenlei=request.getParameter("fenlei");
			String spname=request.getParameter("spname");
			int cknumber=Integer.parseInt(request.getParameter("cknumber"));
			Date cktime=Date.valueOf(request.getParameter("ckdate"));
			chuku ra=new chuku();
			ra.setFenlei(fenlei);
			ra.setSpname(spname);
			ra.setCknumber(cknumber);
			ra.setCktime(cktime);
			chukudao rr=new chukudao();
			r=rr.addchuku(ra);
			response.getWriter().print(r);
		}
		else if(actionUrl.equals("/jsp/deletechuku.do"))
		{
			int r=0;
			String fenlei=request.getParameter("fenlei");
			String spname=request.getParameter("spname");
			int cknumber=Integer.parseInt(request.getParameter("cknumber"));
			Date cktime=Date.valueOf(request.getParameter("cktime"));
			chuku ra=new chuku();
			ra.setFenlei(fenlei);
			ra.setSpname(spname);
			ra.setCknumber(cknumber);
			ra.setCktime(cktime);
			chukudao rr=new chukudao();
			r=rr.deletechuku(ra);
			response.getWriter().print(r);
		}
	}

}
