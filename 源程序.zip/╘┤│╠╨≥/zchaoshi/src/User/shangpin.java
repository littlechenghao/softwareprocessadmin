package User;

public class shangpin {
	public String fenlei;
	public String spname;
	public int spnumber;
	public String beizhu;
	public String getFenlei() {
		return fenlei;
	}
	public void setFenlei(String fenlei) {
		this.fenlei = fenlei;
	}
	public String getSpname() {
		return spname;
	}
	public void setSpname(String spname) {
		this.spname = spname;
	}
	public int getSpnumber() {
		return spnumber;
	}
	public void setSpnumber(int spnumber) {
		this.spnumber = spnumber;
	}
	public String getBeizhu() {
		return beizhu;
	}
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	
}
