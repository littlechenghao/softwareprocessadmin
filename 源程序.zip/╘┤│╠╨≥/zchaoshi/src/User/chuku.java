package User;

import java.sql.Date;

public class chuku {
	public String fenlei;
	public String spname;
	public int cknumber;
	public Date cktime;
	public String getFenlei() {
		return fenlei;
	}
	public void setFenlei(String fenlei) {
		this.fenlei = fenlei;
	}
	public String getSpname() {
		return spname;
	}
	public void setSpname(String spname) {
		this.spname = spname;
	}
	public int getCknumber() {
		return cknumber;
	}
	public void setCknumber(int cknumber) {
		this.cknumber = cknumber;
	}
	public Date getCktime() {
		return cktime;
	}
	public void setCktime(Date cktime) {
		this.cktime = cktime;
	}
	
}
