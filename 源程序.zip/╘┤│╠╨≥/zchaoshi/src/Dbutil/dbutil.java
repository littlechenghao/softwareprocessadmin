package Dbutil;
import java.sql.*; 
public class dbutil {
	public static Connection getconnection()
	{		 
		Connection conn=null;
		try {  
            Class. forName("oracle.jdbc.driver.OracleDriver");  
            System. out.println("加载数据库驱动成功！" );  
            } 
		catch (ClassNotFoundException e ) {  
            System. out.println("加载数据库驱动失败！" );  
             e.printStackTrace();  
            } 
        try {  
            conn = DriverManager. getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "123456");// @localhost和1521很关键,也就是侦听串里有没有这个    
           System. out.println("创建数据库连接成功！" );  
    } catch (SQLException e ) {  
           System. out.print(conn );  
           System. out.println("创建数据库连接失败！" );  
            conn = null;  
            e.printStackTrace();  
    } 
		return conn;
	}
	public static void close(Connection connection ) {
		try {
			if (connection != null) {
				connection.close();
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void close(PreparedStatement preparedStatement ) {
		try {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void close(ResultSet resultSet ) {
		try {
			if (resultSet != null) {
				resultSet.close();
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
